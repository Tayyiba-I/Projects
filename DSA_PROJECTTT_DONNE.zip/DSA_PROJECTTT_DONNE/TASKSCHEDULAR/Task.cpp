#include "Task.h"

Task::Task(const QString& name, const QDateTime& dueDateTime, int priority)
    : name(name), dueDateTime(dueDateTime), priority(priority) {}

QString Task::getName() const {
    return name;
}

QDateTime Task::getDueDateTime() const {
    return dueDateTime;
}

int Task::getPriority() const {
    return priority;
}

bool Task::operator==(const Task& other) const {
    return name == other.name && dueDateTime == other.dueDateTime && priority == other.priority;
}


