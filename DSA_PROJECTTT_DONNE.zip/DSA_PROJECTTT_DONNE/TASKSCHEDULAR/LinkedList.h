#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>
#include "TaskManager.h"
using namespace std;

struct TaskComparator;

template <typename T>
class Node {
public:
    T data;
    Node* next;

    Node() : data(T()), next(nullptr) {}
    Node(T dt) : data(dt), next(nullptr) {}
};

template <typename T>
class LinkedList {
public:
    Node<T>* head;

    LinkedList() : head(nullptr) {}

    bool isEmpty() {
        return head == nullptr;
    }

    void insertFront(T value) {
        Node<T>* newNode = new Node<T>(value);
        newNode->next = head;
        head = newNode;
    }

    void insertEnd(T value) {
        Node<T>* newNode = new Node<T>(value);
        if (isEmpty()) {
            head = newNode;
            return;
        }

        Node<T>* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    void deleteThis(const Task& taskToDelete) {
        QString value = taskToDelete.getName();
        Node<T>* current = head;
        Node<T>* previous = nullptr;

        while (current != nullptr && current->data.getName() != value) {
            previous = current;
            current = current->next;
        }
        if (current == nullptr) {
            return;
        }
        if (previous == nullptr) {
            head = current->next;
        } else {
            previous->next = current->next;
        }
        delete current;
    }

    void deleteFront() {
        if (isEmpty()) {
            return;
        }
        Node<T>* temp = head;
        head = head->next;
        delete temp;
    }

    void deleteEnd() {
        if (isEmpty()) {
            return;
        }
        if (head->next == NULL) {
            delete head;
            head = NULL;
            return;
        }
        Node<T>* temp = head;
        while (temp->next->next != NULL) {
            temp = temp->next;
        }
        delete temp->next;
        temp->next = NULL;
    }

    void sort(TaskComparator& comparator) {
        if (head == nullptr || head->next == nullptr) {
            return;  // Already sorted or empty list
        }

        Node<T>* current = head;
        Node<T>* index = nullptr;
        T temp;

        while (current != nullptr) {
            index = current->next;

            while (index != nullptr) {
                // Swap if the data of the current node is greater than the data of the next node
                if (comparator(current->data, index->data)) {
                    temp = current->data;
                    current->data = index->data;
                    index->data = temp;
                }
                index = index->next;
            }
            current = current->next;
        }
    }

    class Iterator {
    public:
        Node<T>* current;

        Iterator(Node<T>* start) : current(start) {}

        T& operator*() const {
            return current->data;
        }

        Iterator& operator++() {
            current = current->next;
            return *this;
        }

        bool operator!=(const Iterator& other) const {
            return current != other.current;
        }
    };

    Iterator begin() const {
        return Iterator(head);
    }

    Iterator end() const {
        return Iterator(nullptr);
    }


    void displayAllTasks() {
        Node<T>* temp = head;
        while (temp != nullptr) {
            qDebug() << "Task: " << temp->data.getName()
                      << ", Due: " << temp->data.getDueDateTime().toString("MMMM d, yyyy h:mm AP")
                      << ", Priority: " << temp->data.getPriority() << endl;
            temp = temp->next;
        }
    }

};

#endif // LINKEDLIST_H
