// CustomPriorityQueue.h
#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H

#include "LinkedList.h"
#include "TaskManager.h"

struct TaskComparator;

template <typename T,typename Container = LinkedList<T>, typename Comparator = TaskComparator>
class PriorityQueue {
private:
    Container elements;
    Comparator comparator;

public:
    PriorityQueue(const Comparator& comp = Comparator()) : comparator(comp) {}

    void enqueue(const T& value) {
        elements.insertFront(value);
        elements.sort(comparator);
    }

    T dequeue() {
        if (isempty()) {
            return T();
        }

        T data = elements.head->data;
        elements.deleteFront();
        return data;
    }

    bool isempty(){
        return elements.isEmpty();
    }

    T top(){
        if (isempty()) {
            return T();
        }
        return elements.head->data;
    }

    void deletethisvalue(const Task& tasktoDelete) {
        elements.deleteThis(tasktoDelete);
        elements.sort(comparator);
    }
};

#endif
