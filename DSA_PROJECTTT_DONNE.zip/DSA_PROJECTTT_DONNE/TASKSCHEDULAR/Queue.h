// Queue.h
#ifndef QUEUE_H
#define QUEUE_H

#include "LinkedList.h"

template <typename T>
class Queue : public LinkedList<T> {
public:
    void enqueue(T value) {
        this->insertFront(value);
    }

    void dequeue() {
        this->deleteFront();
    }

    void removeElement(const Task& tasktoDelete){
        this->deleteThis(tasktoDelete);
    }
};


#endif // QUEUE_H
