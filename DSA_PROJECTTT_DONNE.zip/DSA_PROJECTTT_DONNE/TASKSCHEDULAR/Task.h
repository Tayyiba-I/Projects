#ifndef TASK_H
#define TASK_H

#include <QString>
#include <QDateTime>

class Task {
private:
    QString name;
    QDateTime dueDateTime;
    int priority;

public:
    Task() = default;
    Task(const QString& name, const QDateTime& dueDateTime, int priority);

    QString getName() const;
    QDateTime getDueDateTime() const;
    int getPriority() const;
    bool operator==(const Task& other) const;
};

#endif
