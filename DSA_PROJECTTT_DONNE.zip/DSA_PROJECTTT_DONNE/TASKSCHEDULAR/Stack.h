// Stack.h
#ifndef STACK_H
#define STACK_H

#include "LinkedList.h"

template <typename T>
class Stack {
private:
    LinkedList<T> elements;
public:
    Node<T>* head;
    void push(T value) {
        // this->insertFront(value);
        elements.insertFront(value);
    }

    void pop() {
        // this->deleteFront();
        elements.deleteFront();
    }

    T top() {
        if (elements.isEmpty()) {
            return T(); // Assuming T() represents an error or default value
        }
        return elements.head->data;
    }

    bool isEmpty(){
        return elements.isEmpty();
    }

    void deletethis(const T& value) {
        Node<T>* current = this->head;
        Node<T>* previous = nullptr;

        while (current != nullptr) {
            if (current->data == value) {
                // Node with the value found, remove it
                if (previous == nullptr) {
                    // If the value is in the head, update the head
                    this->head = current->next;
                } else {
                    // If the value is in the middle or end, update the pointers
                    previous->next = current->next;
                }

                // Delete the node
                delete current;

                // Exit the loop after deleting the node
                break;
            } else {
                // Move to the next node
                previous = current;
                current = current->next;
            }
        }
    }
};

#endif // STACK_H
