#ifndef TASKMANAGER_H
#define TASKMANAGER_H

#include "Task.h"

#include <QWidget>
#include <QListWidget>

#include "Stack.h"
#include "LinkedList.h"
#include "PriorityQueue.h"

// // Custom comparator for priority_queue
struct TaskComparator {
    bool operator()(const Task& task1, const Task& task2) const {
        if (task1.getDueDateTime() > task2.getDueDateTime()) {
            return true;
        } else if (task1.getDueDateTime() == task2.getDueDateTime()) {
            if (task1.getPriority() > task2.getPriority())
                return true;
        }
        return false;
    }
};

class QLabel;
class QLineEdit;
class QDateTimeEdit;
class QComboBox;
class QPushButton;
class QListWidgetItem;

class TaskManager : public QWidget {
    Q_OBJECT

public:
    TaskManager(QWidget* parent = nullptr);

private slots:
    void handleTaskSubmission();
    void handleUndo();
    void handleRedo();
    void handleNextTask();
    void handleViewAllTasks();

public:
    void setupUi();

    Stack<Task> tasksStack;
    Stack<Task> tasksStackRedo;
    LinkedList<Task> tasksLinkedList;
    PriorityQueue<Task, LinkedList<Task>, TaskComparator> tasksPriorityQueue;

    QLineEdit* taskLineEdit;
    QDateTimeEdit* dueDateTimeEdit;
    QComboBox* priorityComboBox;
    QLabel* suggestionLabel;
    QListWidget* taskListWidget;

    QPushButton* submitButton;
    QPushButton* undoButton;
    QPushButton* redoButton;
    QPushButton* handleNextTaskButton;
    QPushButton* viewAllTasksButton;
};
#endif
