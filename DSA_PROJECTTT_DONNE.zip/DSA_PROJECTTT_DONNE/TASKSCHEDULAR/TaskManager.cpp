#include "TaskManager.h"
#include "Task.h"

#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QDateTimeEdit>
#include <QComboBox>
#include <QPushButton>
#include <QDebug>
#include <QString>
#include <QListWidget>

TaskManager::TaskManager(QWidget* parent) : QWidget(parent) {
    setupUi();
}

void TaskManager::setupUi() {
    QVBoxLayout* layout = new QVBoxLayout(this);

    QLabel* taskLabel = new QLabel("Task:");
    taskLineEdit = new QLineEdit(this);

    QLabel* dueDateLabel = new QLabel("Due Date and Time:");
    dueDateTimeEdit = new QDateTimeEdit(QDateTime::currentDateTime(), this);

    QLabel* priorityLabel = new QLabel("Priority (1 to 5):");
    priorityComboBox = new QComboBox(this);
    for (int i = 1; i <= 5; ++i) {
        priorityComboBox->addItem(QString::number(i));
    }

    QPushButton* submitButton = new QPushButton("Submit", this);
    suggestionLabel = new QLabel(" ");

    undoButton = new QPushButton("Undo", this);
    redoButton = new QPushButton("Redo", this);
    handleNextTaskButton = new QPushButton("Do This Now", this);
    viewAllTasksButton = new QPushButton("View All Tasks", this);

    layout->addWidget(taskLabel);
    layout->addWidget(taskLineEdit);
    layout->addWidget(dueDateLabel);
    layout->addWidget(dueDateTimeEdit);
    layout->addWidget(priorityLabel);
    layout->addWidget(priorityComboBox);
    layout->addWidget(submitButton);
    layout->addWidget(suggestionLabel);
    layout->addWidget(undoButton);
    layout->addWidget(redoButton);
    layout->addWidget(handleNextTaskButton);
    layout->addWidget(viewAllTasksButton);

    connect(submitButton, &QPushButton::clicked, this, &TaskManager::handleTaskSubmission);
    connect(undoButton, &QPushButton::clicked, this, &TaskManager::handleUndo);
    connect(redoButton, &QPushButton::clicked, this, &TaskManager::handleRedo);
    connect(handleNextTaskButton, &QPushButton::clicked, this, &TaskManager::handleNextTask);
    connect(viewAllTasksButton, &QPushButton::clicked, this, &TaskManager::handleViewAllTasks);
}

void TaskManager::handleTaskSubmission() {
    QString taskName = taskLineEdit->text();
    // Exception Handling
    if (taskName.isEmpty()) {
        suggestionLabel->setText("Error: Task name cannot be empty");
        taskName = taskLineEdit->text();
        return;
    }

    QDateTime dueDateTime = dueDateTimeEdit->dateTime();
    int priority = priorityComboBox->currentText().toInt();

    Task newTask(taskName, dueDateTime, priority);

    tasksStack.push(newTask);
    tasksLinkedList.insertFront(newTask);
    tasksPriorityQueue.enqueue(newTask);
    suggestionLabel->setText("Task added: " + taskName);
    taskLineEdit->clear();
}

void TaskManager::handleUndo() {
    if (!tasksStack.isEmpty()) {
        Task task = tasksStack.top();
        tasksStack.pop();
        tasksLinkedList.deleteFront();
        tasksStackRedo.push(task);            // push Top element for Redo Operation.
        suggestionLabel->setText("Undo: Task '" + task.getName() + "' is removed.");
    } else {
        suggestionLabel->setText("Undo: No more tasks to undo");

    }
}

void TaskManager::handleRedo() {
    if (!tasksStackRedo.isEmpty()) {
        Task task = tasksStackRedo.top();
        tasksStackRedo.pop();
        tasksLinkedList.insertFront(task);
        tasksPriorityQueue.enqueue(task);
        tasksStack.push(task);
        suggestionLabel->setText("Redo: Task '" + task.getName() + "' is added.");
    } else {
        suggestionLabel->setText("Redo: No more tasks to redo");
    }
}

void TaskManager::handleNextTask() {
    // Check if there are tasks in the priority queue
    if (tasksPriorityQueue.isempty()) {
        suggestionLabel->setText("No tasks available.");
        return;
    }

    // Get the next task from the priority queue (with the highest priority and earliest due date)
    Task nextTask = tasksPriorityQueue.top();

    // Display the next task
    suggestionLabel->setText("Do This Task: " + nextTask.getName() +
                             ", Due: " + nextTask.getDueDateTime().toString("MMMM d, yyyy h:mm AP") +
                             ", Priority: " + QString::number(nextTask.getPriority()));

    tasksStack.deletethis(nextTask);
    tasksLinkedList.deleteThis(nextTask);
    tasksPriorityQueue.deletethisvalue(nextTask);
}

void TaskManager::handleViewAllTasks() {
    // Create a new window to display all tasks
    QWidget* tasksDisplay = new QWidget();
    tasksDisplay->setWindowTitle("All Tasks");
    QVBoxLayout* layout = new QVBoxLayout(tasksDisplay);

    // Iterate over the tasks in the linked list and add them to a QListWidget
    QListWidget* taskListWidget = new QListWidget();
    for (const Task& task : tasksLinkedList) {
        QString taskInfo = QString("Task: %1, Due: %2, Priority: %3")
                               .arg(task.getName())
                               .arg(task.getDueDateTime().toString("MMMM d, yyyy h:mm AP"))
                               .arg(task.getPriority());
        QListWidgetItem* item = new QListWidgetItem(taskInfo);
        taskListWidget->addItem(item);
    }

    layout->addWidget(taskListWidget);

    tasksDisplay->show();
}
