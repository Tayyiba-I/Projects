/****************************************************************************
** Meta object code from reading C++ file 'TaskManager.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../TASKSCHEDULAR/TaskManager.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TaskManager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSTaskManagerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSTaskManagerENDCLASS = QtMocHelpers::stringData(
    "TaskManager",
    "handleTaskSubmission",
    "",
    "handleUndo",
    "handleRedo",
    "handleNextTask",
    "handleViewAllTasks"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSTaskManagerENDCLASS_t {
    uint offsetsAndSizes[14];
    char stringdata0[12];
    char stringdata1[21];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[11];
    char stringdata5[15];
    char stringdata6[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSTaskManagerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSTaskManagerENDCLASS_t qt_meta_stringdata_CLASSTaskManagerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 11),  // "TaskManager"
        QT_MOC_LITERAL(12, 20),  // "handleTaskSubmission"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 10),  // "handleUndo"
        QT_MOC_LITERAL(45, 10),  // "handleRedo"
        QT_MOC_LITERAL(56, 14),  // "handleNextTask"
        QT_MOC_LITERAL(71, 18)   // "handleViewAllTasks"
    },
    "TaskManager",
    "handleTaskSubmission",
    "",
    "handleUndo",
    "handleRedo",
    "handleNextTask",
    "handleViewAllTasks"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSTaskManagerENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   44,    2, 0x08,    1 /* Private */,
       3,    0,   45,    2, 0x08,    2 /* Private */,
       4,    0,   46,    2, 0x08,    3 /* Private */,
       5,    0,   47,    2, 0x08,    4 /* Private */,
       6,    0,   48,    2, 0x08,    5 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject TaskManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSTaskManagerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSTaskManagerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSTaskManagerENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<TaskManager, std::true_type>,
        // method 'handleTaskSubmission'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleUndo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleRedo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleNextTask'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleViewAllTasks'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void TaskManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TaskManager *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->handleTaskSubmission(); break;
        case 1: _t->handleUndo(); break;
        case 2: _t->handleRedo(); break;
        case 3: _t->handleNextTask(); break;
        case 4: _t->handleViewAllTasks(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *TaskManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TaskManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSTaskManagerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int TaskManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 5;
    }
    return _id;
}
QT_WARNING_POP
